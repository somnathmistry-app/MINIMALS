class BaseUrl {
  static String baseUrl =
      'http://minimalshq.com/minimalapp/api/app';
}